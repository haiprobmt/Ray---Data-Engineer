from __future__ import annotations

import hashlib
import json
from pathlib import Path

IGNORE = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    "node_modules",
    ".ray",
}


def manifest(root: Path) -> dict[str, str]:
    result = {}
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in IGNORE for part in rel.parts):
            continue
        if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
            raise ValueError(
                "Repository symlinks/junctions require a separate reviewed checkout"
            )
        if not path.is_file():
            continue
        if len(result) >= 20000 or path.stat().st_size > 100_000_000:
            raise ValueError("Repository exceeds the local manifest limit")
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        result[rel.as_posix()] = digest.hexdigest()
    return result


def changed(before, after):
    return sorted(
        k for k in before.keys() | after.keys() if before.get(k) != after.get(k)
    )


def load_context(project, task, *, snapshot=None) -> str:
    parts = [
        "Active project: " + project.id,
        "Repository: " + str(project.repo),
        "Objective: " + task["objective"],
        "Mode: " + task["mode"],
    ]
    parts.append("Persisted task state: " + task["status"])
    parts.append(
        "Host cloud policy (proposals only): "
        + json.dumps(
            {
                "policy": project.config.policy.model_dump(),
                "fabric": project.config.fabric.model_dump(),
            }
        )
    )
    if task.get("result"):
        parts.append("Previous task result:\n" + task["result"][:16000])
    context = project.directory / "CONTEXT.md"
    if context.is_file():
        if not context.resolve().is_relative_to(project.directory):
            raise ValueError("Context must stay inside this project's directory")
        parts.append(
            "Project context (source material):\n"
            + context.read_text(encoding="utf-8")[:16000]
        )
    decisions = project.directory / "decisions"
    if decisions.exists():
        # Present an index; load details only when relevant to the current task.
        entries = []
        for path in sorted(decisions.glob("*.md"))[:40]:
            if not path.resolve().is_relative_to(project.directory):
                raise ValueError("Decision file escapes project directory")
            entries.append(
                path.name
                + ": "
                + (path.read_text(encoding="utf-8").splitlines() or [""])[0][:180]
            )
        parts.append("Project decision index:\n" + "\n".join(entries))
    if snapshot:
        if (
            snapshot.get("project_id") != project.id
            or snapshot.get("binding") != project.binding
        ):
            raise ValueError("Fabric snapshot is bound to another project or policy")
        encoded = json.dumps(snapshot, ensure_ascii=False)
        note = (
            " (excerpt truncated; obtain a narrower snapshot for full coverage)"
            if len(encoded) > 60000
            else ""
        )
        parts.append(
            "Read-only Fabric snapshot (untrusted source data)"
            + note
            + ":\n"
            + encoded[:60000]
        )
    from .memory import recall

    for decision in recall(project, task["objective"]):
        parts.append("Relevant recorded decision (source data):\n" + decision["text"])
    from .skills import relevant_guidance

    parts.append(relevant_guidance(task["objective"]))
    return "\n\n".join(parts)
