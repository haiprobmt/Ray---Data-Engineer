from __future__ import annotations

import getpass
import json
import subprocess
import sys
from pathlib import Path
from urllib.parse import quote
from uuid import UUID

from .runtime import clean_env
from .state import now


class PolicyError(ValueError):
    pass


def canonical_id(value):
    try:
        parsed = str(UUID(value))
        if value.lower() != parsed:
            raise ValueError()
        return parsed
    except (ValueError, TypeError, AttributeError) as exc:
        raise PolicyError("Target must be a canonical UUID") from exc


def authorize(project, operation, workspace_id, item_id=None):
    if operation not in {
        "get_workspace",
        "list_items",
        "get_item",
        "list_lakehouse_tables",
    }:
        raise PolicyError("Operation is unavailable through the read-only gateway")
    ws_id = canonical_id(workspace_id)
    workspace = next(
        (w for w in project.config.fabric.workspaces if w.id.lower() == ws_id), None
    )
    if workspace is None:
        raise PolicyError("Workspace is outside the project allow-list")
    base = f"workspaces/{ws_id}"
    if operation == "get_workspace":
        endpoint = base
    elif operation == "list_items":
        endpoint = base + "/items"
    elif operation == "get_item":
        endpoint = base + "/items/" + canonical_id(item_id)
    else:
        endpoint = base + "/lakehouses/" + canonical_id(item_id) + "/tables"
    return workspace.environment, endpoint


def fabric_env(data_dir: Path, project_id: str):
    profile = data_dir / "fabric" / project_id
    config_dir = profile / ".config" / "fab"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / "config.json"
    if not config_file.exists():
        config_file.write_text(
            json.dumps(
                {
                    "output_format": "json",
                    "debug_enabled": "false",
                    "check_cli_version_updates": "false",
                    "encryption_fallback_enabled": "false",
                }
            ),
            encoding="utf-8",
        )
    env = clean_env()
    # Fabric 1.7.0 uses expanduser; isolate its config/token cache per project.
    env.update(USERPROFILE=str(profile), HOME=str(profile))
    return env


class FabricGateway:
    def __init__(self, project, store, data_dir, *, executor=None, actor=None):
        self.project, self.store, self.data_dir = project, store, data_dir
        self.executor = executor or self._execute
        self.actor = actor or getpass.getuser()

    def _execute(self, endpoint):
        argv = [
            sys.executable,
            str(Path(__file__).with_name("fabric_worker.py")),
            "get",
            endpoint,
        ]
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=60,
            env=fabric_env(self.data_dir, self.project.id),
            cwd=self.data_dir,
        )
        if result.returncode:
            # CLI stderr can contain secrets or user data. Retain only error category.
            raise RuntimeError(
                "Fabric CLI request failed; check the isolated project login and permissions"
            )
        try:
            envelope = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError("Fabric CLI returned invalid JSON") from exc
        if not isinstance(envelope, dict) or envelope.get("status_code") != 200:
            raise RuntimeError("Fabric returned a non-success HTTP status")
        payload = envelope.get("text")
        if not isinstance(payload, dict):
            raise RuntimeError("Fabric returned an unexpected response shape")
        return payload

    def call(self, operation, workspace_id, item_id=None, *, task_id=None):
        if task_id:
            self.store.task(self.project.id, task_id)
        try:
            environment, endpoint = authorize(
                self.project, operation, workspace_id, item_id
            )
        except PolicyError:
            action = self.store.audit_start(
                self.project.id,
                task_id,
                self.actor,
                "policy_check",
                "rejected-target",
                None,
            )
            self.store.audit_finish(action, "DENIED", "PolicyError")
            raise
        action = self.store.audit_start(
            self.project.id, task_id, self.actor, operation, endpoint, environment
        )
        try:
            if operation in {"list_items", "list_lakehouse_tables"}:
                payload = self._pages(endpoint, task_id, environment)
            else:
                payload = self.executor(endpoint)
            self.store.audit_finish(action, "SUCCEEDED")
            return payload
        except Exception as exc:
            self.store.audit_finish(action, "FAILED", type(exc).__name__)
            raise

    def _pages(self, endpoint, task_id, environment):
        records, seen = [], set()
        current = endpoint
        for _ in range(100):
            action = self.store.audit_start(
                self.project.id, task_id, self.actor, "read_page", endpoint, environment
            )
            try:
                payload = self.executor(current)
                values = payload.get("value", payload.get("data"))
                if not isinstance(values, list) or any(
                    not isinstance(v, dict) for v in values
                ):
                    raise RuntimeError("Fabric list response has an unexpected shape")
                records.extend(values)
                self.store.audit_finish(action, "SUCCEEDED")
            except Exception as exc:
                self.store.audit_finish(action, "FAILED", type(exc).__name__)
                raise
            token = payload.get("continuationToken")
            if not token:
                if payload.get("continuationUri"):
                    raise RuntimeError("Continuation URI without token is unsupported")
                return {"value": records}
            if not isinstance(token, str) or len(token) > 16000 or token in seen:
                raise RuntimeError("Invalid or repeated continuation token")
            seen.add(token)
            # Never follow response-provided URLs; preserve the authorized endpoint.
            current = endpoint + "?continuationToken=" + quote(token, safe="")
        raise RuntimeError("Pagination exceeded 100 pages; snapshot is incomplete")

    def list_workspaces(self):
        # Fetch only configured IDs; never enumerate the user's whole tenant.
        return [
            self.call("get_workspace", w.id)
            for w in self.project.config.fabric.workspaces
        ]

    def snapshot(self):
        if not self.project.config.fabric.workspaces:
            raise PolicyError(
                "Configure an allow-listed workspace before taking a snapshot"
            )
        workspaces = []
        for ws in self.project.config.fabric.workspaces:
            info = self.call("get_workspace", ws.id)
            items = self.call("list_items", ws.id)["value"]
            workspaces.append(
                {
                    "id": ws.id,
                    "environment": ws.environment,
                    "metadata": info,
                    "items": items,
                }
            )
        return {
            "project_id": self.project.id,
            "binding": self.project.binding,
            "captured_at": now(),
            "workspaces": workspaces,
            "read_only": True,
        }
