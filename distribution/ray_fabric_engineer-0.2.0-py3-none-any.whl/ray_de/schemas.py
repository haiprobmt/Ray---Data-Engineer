from typing import Literal
from pydantic import Field, model_validator
from .config import StrictModel


class CloudProposal(StrictModel):
    operation: Literal["update_definition", "run_job", "deploy_to_test"]
    workspace_id: str
    item_id: str
    definition_path: str


class TurnResult(StrictModel):
    status: Literal[
        "working", "clarification", "approval_required", "completed", "blocked", "error"
    ]
    message: str = Field(min_length=1)
    recommendation: str | None
    question: str | None
    options: list[str]
    evidence: list[str]
    skills_used: list[str]
    cloud_actions: list[CloudProposal] = Field(default_factory=list, max_length=5)

    @model_validator(mode="after")
    def meaningful(self):
        if self.status == "clarification" and (
            not self.question or not self.recommendation
        ):
            raise ValueError("Clarification requires one question and a recommendation")
        if self.status == "completed" and not self.evidence:
            raise ValueError("Completion requires evidence")
        if self.status != "clarification" and self.question:
            raise ValueError("A question belongs to a clarification result")
        return self


class ReviewResult(StrictModel):
    verdict: Literal["PASS", "PASS_WITH_COMMENTS", "REWORK", "BLOCK"]
    summary: str = Field(min_length=1)
    findings: list[str]
    evidence: list[str] = Field(min_length=1)
