"""One host workflow shared by the terminal and Telegram channel."""

from __future__ import annotations
import json
from .cloud import CloudActions
from .control import Control, TaskStopped
from .fabric import FabricGateway
from .orchestrator import Orchestrator


class TaskService:
    def __init__(self, store, runner, data_dir):
        self.store, self.runner, self.data_dir = store, runner, data_dir

    def run(self, project, task_id, message, actor, *, snapshot=None, cancel=None):
        token = cancel or Control(self.store).token(project.id)
        if snapshot is None and project.config.fabric.workspaces:
            snapshot = FabricGateway(
                project, self.store, self.data_dir, actor=actor
            ).snapshot()
        token.check()
        report = Orchestrator(self.store, self.runner).run(
            project, task_id, message, snapshot=snapshot, cancel=token
        )
        if report["status"] != "completed":
            return report
        cloud = CloudActions(project, self.store, self.data_dir)
        try:
            proposals = report.get("cloud_actions", [])
            # Reject any unsupported target before starting a sequence of writes.
            for proposal in proposals:
                cloud._target(
                    proposal["operation"], proposal["workspace_id"], proposal["item_id"]
                )
            # Preserve explicit order: a job can validate a just-updated definition.
            for proposal in proposals:
                token.check()
                plan = cloud.prepare(task_id, actor=actor, **proposal)
                token.check()
                if plan["state"] == "READY":
                    outcome = cloud.execute(plan["id"], actor)
                    if outcome["state"] != "SUCCEEDED":
                        break
            with self.store.connect() as db:
                has_plans = db.execute(
                    "SELECT 1 FROM plans WHERE project_id=? AND task_id=?",
                    (project.id, task_id),
                ).fetchone()
            if has_plans:
                cloud._sync_task(task_id)
                return json.loads(self.store.task(project.id, task_id)["result"])
        except TaskStopped:
            self.store.update(project.id, task_id, "PAUSED")
            raise
        except Exception as exc:
            # No model text can turn a rejected or uncertain cloud action into success.
            report.update(
                status="blocked",
                message="Cloud action needs attention: " + type(exc).__name__,
            )
            self.store.update(project.id, task_id, "BLOCKED", result=report)
            return report
        return report
